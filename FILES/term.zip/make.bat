@echo off
c:\c--\c-- terminal
if errorlevel 1 goto end
c:\c--\c-- wterm
del terminal.exe
:end