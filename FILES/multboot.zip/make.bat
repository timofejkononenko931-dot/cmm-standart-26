@echo off
del multboot.dat
c:\c--\c-- multboot.c--
rename multboot.com *.dat
del zagr.dat
c:\c--\c-- zagr.c--
rename zagr.com *.dat
c:\c--\c-- smb.c--
