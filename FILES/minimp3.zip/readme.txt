      Mp3 Player - demonstrating the use of the mci macros
      ----------------------------------------------------

Mp3 Player (Imaginative name! I think it ranks with 'APL' - 'A Programming Language' in terms of least exciting name) is a little program that I have been writing in my spare time.  The main goal of this project was to get a working mp3 player which works with playlists.  As you probably know, no decoding is actually done by the player and it just uses the file 'Msvfw32.dll', which is used by windows media player, to play most media types.

This is inspired by programs written by the Test Department (linked below), and a program written by Ron Thomas (linked below also).  The whole thing is centred around a window which is created by the API MCIWndCreate from the dll 'Msvfw32.dll'.  I made this API invokeable through mcicreate.lib which only contains that single API, as most of the other API's can be reached though vfw32.inc and vfw32.lib whereas MCIWndCreate cannot.

The most useful part of this demonstration is that I have compiled the mci macros as referenced in MSDN into both macro form and invokable form so that they can be included by other people in their projects.  The advantage of using these macros is that they are more readable/easily implemented compared to the alternative of sending each message to the mci window using SendMessage.  Please note that I have only tried out a few of the macros and that while I know these work, I don't know about the others!  If you find anything wrong with the others then you should easily be able to correct the problem yourself using MSDN.  If there are any errors then please tell me and I'll be grateful.  It is highly likely that there will be a few errors as the macros were written by hand and there are a lot of them so I may have overlooked something.

The main mp3 player code uses the invokable versions of the macros and the mini-mp3 player uses the actual macros as you normally use macros.

The project lacks a few features but I'll leave them for you to add!  Enjoy!

Note:
-----
In order for these programs to work you need to have the file 'Msvfw32.dll' present on your system.  If it isn't present then you need to install windows media player, the easiest way to get this is to look at distributions of Internet Explorer found on most demo CDs.  Just install and ask to do a Expert install and select to install windows media player (ignore the rest).  Also you need to the following entry present in your system.ini file under the [mci] section:

MPEGVideo=mciqtz.drv

Thanks to people on the message board who helped me with the above system.ini problem, perhaps I should have read Ron Thomas' help file!  That's all!

Mail me: lordrhesus@yahoo.co.uk

Test Department
---------------

http://surf.to/TestD
http://www.geocities.com/Paris/Cafe/8444/index.html
http://www.crosswinds.net/~testd/index.html
http://redrival.com/testd/index.html

Ron Thomas
----------

www.rbthomas.freeserve.co.uk