            wxCmm version 0.2 Aug 2004

Introduction
============

        wxCmm is wxWidgets for Sphinx C--.

        wxWidgets is a popular open source framework, and wxCmm is a C--
    library based on the framework. Making C-- GUI programming easy and
    fast is it purpose.



Related Web Sites
=================

        http://www.wxwidgets.org/              ( English )
        http://c--sphinx.narod.ru/indexe.htm   ( English )
