#pragma option w32
#pragma option obj

?include "windows.h--"


void main()
{
MessageBoxA(0, "Hello world!", "C-- hello", MB_OK);

}
