del HELLOW32.EXE
del HELLOW32.ERR
del HelloW32.obj
del HELLOW_32.EXE
del W32.ERR
rem -W32
c-- HelloW32.c
D:\fasm\utils\alink\bin\alink HELLOW32.OBJ win32.lib  -subsys gui -oPE -o HELLOW_32.EXE  >>HELLOW32.ERR
rem -entry _demo

