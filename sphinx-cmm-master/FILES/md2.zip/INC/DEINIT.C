DeInit()
{

IF (md2_model.skins!=0) LocalFree(md2_model.skins);
IF (md2_model.texCoords!=0) LocalFree(md2_model.texCoords);
IF (md2_model.triangles!=0) LocalFree(md2_model.triangles);
IF (LpBufferFrame!=0) LocalFree(LpBufferFrame);

//���⪠ �३��� =======================================


IF (md2_model.frames!=0) {
   LpFrames=md2_model.frames;
   FOR (i=0; i<md2_model.header.numFrames; i++)
	{

        EAX=DSDWORD[LpFrames+#md2_frame_t.vertices];
        IF (EAX!=0) LocalFree(EAX);
        LpFrames+=sizeof(md2_frame_t);


        }
        EAX=md2_model.frames;
        IF (EAX!=0) LocalFree(EAX);
                         }
//===========================================================

//�᢮������� ������ �� PCX ᪨��
IF (LpBufferRGB!=0) LocalFree(LpBufferRGB);


}
