    This library an header of files for making the programs under Windows by
means of compiler Sphinx C-- v239b22.  For base were take header files
Borland C++ Builder 6.  Marketed only minimum necessary files.  Hereinafter,
on measure need, library will be renewed.

    This library was tested on examples of programs available by me.  For
majority of programs enough to remove inclusion an header files of old
library and determination of identifiers of use an header of files and add
#include <windows.h> (there is need for some examples to add and #include
<commctrl.h>).  A conflict were in several examples with names variable and
functions.  If You appeared the difficulty on use the new library, or there
is offers on its improvement or additions, that writes me.  I shall pleased
Your help and help You.


							 18.05.2005
							 sheker@mail.ru
							 Michael Sheker.
