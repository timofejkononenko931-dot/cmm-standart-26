@echo off
echo.
echo *** Creating libraries
if not exist kernel32.lib .\tools\dll2lib kernel32.dll > nul
if not exist user32.lib .\tools\dll2lib user32.dll > nul
echo.
echo *** Compressing text file
.\tools\packer c example.txt _.bin > nul
.\tools\bin2inc _.bin text.inc > nul
echo.
echo *** Assembling Z_Decode routine
\masm32\bin\ml /c /coff z_decode.asm
echo.
echo *** Compiling C-- test file
\c--\c-- example.c--
echo.
echo *** Linking
\masm32\bin\link /ENTRY:start /SUBSYSTEM:WINDOWS example.obj z_decode.obj kernel32.lib user32.lib /MERGE:.text=MASM32 /SECTION:MASM32,RWE /MERGE:.rdata=MASM32 /IGNORE:4033,4078
echo.
echo *** Cleanup
del *.inc *.obj *.tds *.bin *.db *.err
del *.lib
pause

