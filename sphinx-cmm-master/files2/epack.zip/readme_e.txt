1. Introduction
----------------

	Probably, You have already noticed that program, written on C-- for
Windows, can not be correct are compressed by compressors UPX and ASPACK.
Program EPack, this attempt to fill this gap.


2. How this program appeared
-----------------------------

	Initial variant of program EPack was sended me in 2001 from
xdeviator@yahoo.com with request not to publish its while.  Author wanted in
her to correct the errors and make the commentary.  Program present itself
simplified variant of program UPX with GUI-interface and with such, either as
by UPX defects.  Thereafter from author of program anymore was no messages.
Most recently, viewing its archive, I ed on this program.  Author of program
was written letter, with request to make clear the fate of program.  But his
mailbox already does not exist.  So I, without consent of author, cause
corrections and improvements in this program.


3. Possibilities of program
----------------------------

	Program EPack compresses the executable files a format PE written on
C--.  Program can work and in GUI and in console format.  If program to start
without parameters, that it will work with GUI-interface.  If in command line
when start, will is specified what that parameter, that program will work in
console mode.  Program can compress the files two methods.


4. Known defect
----------------

	DLL files are compressed, but do not work orderly.


5. Compiling the program
-------------------------

	For compiling the program to is necessary start the file MAKE.BAT.
If You place of finding a compiler is not specified in variable encirclement
'C--' or in variable encirclement 'path' is not specified way to compiler
then for compiling the program, You required when start MAKE.BAT to reference
parameter a way to compiler.


6. Most Further fate of program
--------------------------------

	I offer to do the project EPack as open source.  If You know, how
perfect existing program, that writes about this me on sheker@mail.ru.  Here
is on than, on my look, possible and necessary to concern with in this
project:  in the first place it searching and correct errors; add new methods
of compression; improvement an interface - make its more suitable.


7. Authors and coauthor
------------------------

xdeviator@yahoo.com - has writed main part of program: algorithm of
	compression, transformations a structure of packed files,
	GUI-interface.

sheker@mail.ru - has copied and optimized source text of program under
	present possibilities a compiler, correct errors in procedures of
	work with resources, rewrite on C-- with assembler blocks
	decompressor, permitted to pack the files, written on C--, has added
	the console interface.

