This is very alpha version of the IDE:
- uses KetilO RAEdit custom control for highlighting the source
- uses wxCmm (using very little of the features)
- SHIFT+F1 - show keyboard shortcuts
- lot of bugs :)
- hardcoded paths
- it just quick hack for testing some ideeas


                                 TBD    mail to: tbd@despammed.com