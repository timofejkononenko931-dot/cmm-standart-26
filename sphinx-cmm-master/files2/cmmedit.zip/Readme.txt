 - Some modification to KetilO's RAEdit.dll to make it case sensitive without using '^'.
 - To create new project, right click project window, click Open Project, type in new project name.
   or from main menu choose Project -> Open Project
 - To add or delete file into project, right click project window, click add or delete file.
 - The main file in project window must be the same as project name in order to compile successfully
   eg. C--IDE.C-- (main file), C--IDE.cmp (project file)
 - Alternately, you can compile C-- files without creating new project with the condition
   the project is empty and you must click main C-- file tab before compiling / running. 

ERROR
 - Open a file, open a project, click property window, press F6 to refresh, property window show double function. >_<
   Anyone can help ? ^_^
   
NOT FINISHED YET
 - Replace function. :)

