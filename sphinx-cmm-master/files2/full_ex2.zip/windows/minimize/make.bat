@echo off
c:\c--\c-- minimize
wrc minimize.res