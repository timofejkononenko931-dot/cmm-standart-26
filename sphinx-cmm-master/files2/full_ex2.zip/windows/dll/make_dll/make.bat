@echo off
c:\c--\c-- /dll c--dll
