@echo off
c:\c--\c-- hello