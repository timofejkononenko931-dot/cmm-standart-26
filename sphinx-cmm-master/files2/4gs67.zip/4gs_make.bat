@echo off
rem
rem     create DOS4G stub
rem
e:\c--\c-- 4gs.c--
rem
rem     make example
rem
wcl386 /y /ox /c /3 /bt=dos4g args.cpp
wlink system dos4g op stub=4gs.exe file args.obj
rem
rem     Test of 4GSTUB.EXE : ARGS - Output arguments
rem
echo ----------------------------------------------- TEST
args Argument1 "Argument2 + text" 1234 -C Hello !
