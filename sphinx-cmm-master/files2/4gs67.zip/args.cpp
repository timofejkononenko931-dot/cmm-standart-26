/*
	Example for stub : 4GS.EXE
*/
#include <stdio.h>
#include <stdlib.h>

void main( int argc, char *argv[] ) {
//
// output arguments
//
	for ( int i = 0; i < argc; i++ )
		puts( argv[i] );
//
// output environ
//
	system( "pause" );
	system( "SET" );
}
