if exist mb.com del mb.com
c-- mb.c--
if exist mb.com pklite.exe mb.com
if exist mb.com mb.com
