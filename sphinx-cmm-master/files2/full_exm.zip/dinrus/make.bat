@echo off
if exist dinrus.c-- c--.exe dinrus.c--
if exist dinrus.com pklite dinrus.com
if exist warning del warning