c-- myvxd.cmm
C:\soft\lang\masm_\LINK.EXE /nologo /VXD myvxd.obj /DEF:myvxd.def
del myvxd.exp
del myvxd.lib
del myvxd.obj
