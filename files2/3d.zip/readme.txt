usage:
3d.exe *.3ds
keys:
<home> <end> - zoom
<left> <right> <down> <up> - move object
<esc> - exit
