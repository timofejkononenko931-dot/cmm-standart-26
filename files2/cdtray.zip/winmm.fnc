#define DrvOpen                DrvOpenA
#define OpenDriver             OpenDriverA
#define PlaySound              PlaySoundA
#define auxGetDevCaps          auxGetDevCapsA
#define joyGetDevCaps          joyGetDevCapsA
#define mciGetErrorString      mciGetErrorStringA
#define mciSendCommand         mciSendCommandA
#define mciSendString          mciSendStringA
#define midiInGetDevCaps       midiInGetDevCapsA
#define midiInGetErrorText     midiInGetErrorTextA
#define midiOutGetDevCaps      midiOutGetDevCapsA
#define midiOutGetErrorText    midiOutGetErrorTextA
#define mixerGetControlDetails mixerGetControlDetailsA
#define mixerGetDevCaps        mixerGetDevCapsA
#define mixerGetLineControls   mixerGetLineControlsA
#define mixerGetLineInfo       mixerGetLineInfoA
#define mmioInstallIOProc      mmioInstallIOProcA
#define mmioOpen               mmioOpenA
#define mmioRename             mmioRenameA
#define mmioStringToFOURCC     mmioStringToFOURCCA
#define sndPlaySound           sndPlaySoundA
#define waveInGetDevCaps       waveInGetDevCapsA
#define waveInGetErrorText     waveInGetErrorTextA
#define waveOutGetDevCaps      waveOutGetDevCapsA
#define waveOutGetErrorText    waveOutGetErrorTextA



extern WINAPI "winmm.dll"
{
CloseDriver();
DefDriverProc();
DriverCallback();
DrvClose();
DrvDefDriverProc();
DrvGetModuleHandle();
DrvOpen();
//DrvOpenA();
DrvSendMessage();
GetDriverFlags();
GetDriverModuleHandle();
OpenDriver();
//OpenDriverA();
PlaySound();
//PlaySoundA();
PlaySoundW();
SendDriverMessage();
auxGetDevCapsA();
auxGetDevCapsW();
auxGetNumDevs();
auxGetVolume();
auxOutMessage();
auxSetVolume();
joyConfigChanged();
joyGetDevCapsA();
joyGetDevCapsW();
joyGetNumDevs();
joyGetPos();
joyGetPosEx();
joyGetThreshold();
joyReleaseCapture();
joySetCapture();
joySetThreshold();
mciDriverNotify();
mciDriverYield();
mciExecute();
mciFreeCommandResource();
mciGetCreatorTask();
mciGetDeviceIDA();
mciGetDeviceIDFromElementIDW();
mciGetDeviceIDW();
mciGetDriverData();
mciGetErrorStringA();
mciGetErrorStringW();
mciGetYieldProc();
mciLoadCommandResource();
mciSendCommandA();
mciSendCommandW();
mciSendStringA();
mciSendStringW();
mciSetDriverData();
mciSetYieldProc();
midiConnect();
midiDisconnect();
midiInAddBuffer();
midiInClose();
midiInGetDevCapsA();
midiInGetDevCapsW();
midiInGetErrorTextA();
midiInGetErrorTextW();
midiInGetID();
midiInGetNumDevs();
midiInMessage();
midiInOpen();
midiInPrepareHeader();
midiInReset();
midiInStart();
midiInStop();
midiInUnprepareHeader();
midiOutCacheDrumPatches();
midiOutCachePatches();
midiOutClose();
midiOutGetDevCapsA();
midiOutGetDevCapsW();
midiOutGetErrorTextA();
midiOutGetErrorTextW();
midiOutGetID();
midiOutGetNumDevs();
midiOutGetVolume();
midiOutLongMsg();
midiOutMessage();
midiOutOpen();
midiOutPrepareHeader();
midiOutReset();
midiOutSetVolume();
midiOutShortMsg();
midiOutUnprepareHeader();
midiStreamClose();
midiStreamOpen();
midiStreamOut();
midiStreamPause();
midiStreamPosition();
midiStreamProperty();
midiStreamRestart();
midiStreamStop();
mixerClose();
mixerGetControlDetailsA();
mixerGetControlDetailsW();
mixerGetDevCapsA();
mixerGetDevCapsW();
mixerGetID();
mixerGetLineControlsA();
mixerGetLineControlsW();
mixerGetLineInfoA();
mixerGetLineInfoW();
mixerGetNumDevs();
mixerMessage();
mixerOpen();
mixerSetControlDetails();
mmioAdvance();
mmioAscend();
mmioClose();
mmioCreateChunk();
mmioDescend();
mmioFlush();
mmioGetInfo();
mmioInstallIOProc16();
mmioInstallIOProcA();
mmioInstallIOProcW();
mmioOpenA();
mmioOpenW();
mmioRead();
mmioRenameA();
mmioRenameW();
mmioSeek();
mmioSendMessage();
mmioSetBuffer();
mmioSetInfo();
mmioStringToFOURCCA();
mmioStringToFOURCCW();
mmioWrite();
mmsystemGetVersion();
sndPlaySoundA();
sndPlaySoundW();
timeBeginPeriod();
timeEndPeriod();
timeGetDevCaps();
timeGetSystemTime();
timeGetTime();
timeKillEvent();
timeSetEvent();
waveInAddBuffer();
waveInClose();
waveInGetDevCapsA();
waveInGetDevCapsW();
waveInGetErrorTextA();
waveInGetErrorTextW();
waveInGetID();
waveInGetNumDevs();
waveInGetPosition();
waveInMessage();
waveInOpen();
waveInPrepareHeader();
waveInReset();
waveInStart();
waveInStop();
waveInUnprepareHeader();
waveOutBreakLoop();
waveOutClose();
waveOutGetDevCapsA();
waveOutGetDevCapsW();
waveOutGetErrorTextA();
waveOutGetErrorTextW();
waveOutGetID();
waveOutGetNumDevs();
waveOutGetPitch();
waveOutGetPlaybackRate();
waveOutGetPosition();
waveOutGetVolume();
waveOutMessage();
waveOutOpen();
waveOutPause();
waveOutPrepareHeader();
waveOutReset();
waveOutRestart();
waveOutSetPitch();
waveOutSetPlaybackRate();
waveOutSetVolume();
waveOutUnprepareHeader();
waveOutWrite();
winmmf_ThunkData32();
winmmsl_ThunkData32();
}