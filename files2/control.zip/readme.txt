This example relevant only to WindowsXP.
Detailed information on manifests see MSDN:
"Discover the relationship between Microsoft XML Parser (MSXML) 4.0 and
Microsoft Windows XP, and how to create an application manifest in order to
use MSXML 4.0. (5 printed pages)"
URL:
 http://msdn.microsoft.com/library/en-us/dnmsxml/html/dnmsxmlfusion.asp?frame=true&_r=1
